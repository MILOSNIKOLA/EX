const main = document.querySelector("main");

// ===== STRUCTURE DES NIVEAUX =====
const levels = {
  easy: {
    unlocked: true,
    completed: false,
    exercices: [
      { pic: 0, min: 1 },
      { pic: 1, min: 1 },
      { pic: 2, min: 1 },
      { pic: 3, min: 1 },
      { pic: 4, min: 1 },
    ],
  },
  medium: {
    unlocked: false,
    completed: false,
    exercices: [
      { pic: 0, min: 1 },
      { pic: 1, min: 2 },
      { pic: 2, min: 1 },
      { pic: 3, min: 2 },
      { pic: 4, min: 1 },
      { pic: 5, min: 1 },
    ],
  },
  hard: {
    unlocked: false,
    completed: false,
    exercices: [
      { pic: 0, min: 1 },
      { pic: 1, min: 2 },
      { pic: 2, min: 2 },
      { pic: 3, min: 2 },
      { pic: 4, min: 1 },
      { pic: 5, min: 2 },
      { pic: 6, min: 1 },
      { pic: 7, min: 1 },
      { pic: 8, min: 1 },
      { pic: 9, min: 1 },
    ],
  },
};

let exerciceArray = [];
let currentLevel = "easy";

// ===== Charger les données du localStorage =====
(() => {
  if (localStorage.levels) {
    Object.assign(levels, JSON.parse(localStorage.levels));
  }
  if (localStorage.currentLevel) {
    currentLevel = localStorage.currentLevel;
  }
  exerciceArray = [...levels[currentLevel].exercices];
})();

class Exercice {
  constructor() {
    this.index = 0;
    this.minutes = exerciceArray[this.index].min;
    this.seconds = 0;
  }

  updateCountdown() {
    this.seconds = this.seconds < 10 ? "0" + this.seconds : this.seconds;

    setTimeout(() => {
      if (this.minutes === 0 && this.seconds === "00") {
        this.index++;
        this.ring();
        if (this.index < exerciceArray.length) {
          this.minutes = exerciceArray[this.index].min;
          this.seconds = 0;
          this.updateCountdown();
        } else {
          return page.finish();
        }
      } else if (this.seconds === "00") {
        this.minutes--;
        this.seconds = 59;
        this.updateCountdown();
      } else {
        this.seconds--;
        this.updateCountdown();
      }
    }, 1000);

    return (main.innerHTML = `
      <div class="exercice-container">
        <p>${this.minutes}:${this.seconds}</p>
        <img src="./img/${exerciceArray[this.index].pic}.png" />
        <div>${this.index + 1}/${exerciceArray.length}</div>
      </div>`);
  }

  ring() {
    const audio = new Audio();
    audio.src = "ring.mp3";
    audio.play();
  }
}

const utils = {
  pageContent: function (title, content, btn) {
    document.querySelector("h1").innerHTML = title;
    main.innerHTML = content;
    document.querySelector(".btn-container").innerHTML = btn;
  },

  handleEventMinutes: function () {
    document.querySelectorAll('input[type="number"]').forEach((input) => {
      input.addEventListener("input", (e) => {
        exerciceArray.map((exo) => {
          if (exo.pic == e.target.id) {
            exo.min = parseInt(e.target.value);
            this.store();
          }
        });
      });
    });
  },

  handleEventArrow: function () {
    document.querySelectorAll(".arrow").forEach((arrow) => {
      arrow.addEventListener("click", (e) => {
        let position = 0;
        exerciceArray.map((exo) => {
          if (exo.pic == e.target.dataset.pic && position !== 0) {
            [exerciceArray[position], exerciceArray[position - 1]] = [
              exerciceArray[position - 1],
              exerciceArray[position],
            ];
            page.lobby();
            this.store();
          } else {
            position++;
          }
        });
      });
    });
  },

  deleteItem: function () {
    document.querySelectorAll(".deleteBtn").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        let newArr = [];
        exerciceArray.map((exo) => {
          if (exo.pic != e.target.dataset.pic) {
            newArr.push(exo);
          }
        });
        exerciceArray = newArr;
        page.lobby();
        this.store();
      });
    });
  },

  store: function () {
    localStorage.levels = JSON.stringify(levels);
    localStorage.currentLevel = currentLevel;
  },

  unlockNextLevel: function () {
    const levelOrder = ["easy", "medium", "hard"];
    const currentIndex = levelOrder.indexOf(currentLevel);
    if (currentIndex < levelOrder.length - 1) {
      const nextLevel = levelOrder[currentIndex + 1];
      levels[nextLevel].unlocked = true;
      this.store();
    }
  },
};

const page = {
  levelSelect: function () {
    const levelNames = {
      easy: "Easy 🟢",
      medium: "Medium 🟡",
      hard: "Hard 🔴",
    };

    let levelCards = "";
    Object.entries(levels).forEach(([key, level]) => {
      const isUnlocked = level.unlocked;
      const isCompleted = level.completed;
      const lockClass = !isUnlocked ? "locked" : "";
      const completedClass = isCompleted ? "completed" : "";

      levelCards += `
        <li class="${lockClass} ${completedClass}">
          <h3>${levelNames[key]}</h3>
          <p>${level.exercices.length} exercices</p>
          ${isCompleted ? '<p style="color: green; font-weight: bold;">✓ Complété</p>' : ""}
          ${
            !isUnlocked
              ? '<p style="color: red; font-weight: bold;">🔒 Verrouillé</p>'
              : ""
          }
          <button class="btn-level" data-level="${key}" ${!isUnlocked ? "disabled" : ""}>
            ${isUnlocked ? "Commencer" : "Verrouillé"}
          </button>
        </li>
      `;
    });

    utils.pageContent(
      "Sélectionner un niveau",
      "<ul>" + levelCards + "</ul>",
      "",
    );

    document.querySelectorAll(".btn-level:not(:disabled)").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        currentLevel = e.target.dataset.level;
        exerciceArray = [...levels[currentLevel].exercices];
        utils.store();
        this.lobby();
      });
    });
  },

  lobby: function () {
    let mapArray = exerciceArray
      .map(
        (exo) =>
          `
        <li>
          <div class="card-header">
            <input type="number" id=${exo.pic} min="1" max="10" value=${exo.min}>
            <span>min</span>
          </div>
          <img src="./img/${exo.pic}.png" />
          <i class="fas fa-arrow-alt-circle-left arrow" data-pic=${exo.pic}></i>
          <i class="fas fa-times-circle deleteBtn" data-pic=${exo.pic}></i>
        </li>
      `,
      )
      .join("");

    utils.pageContent(
      `Paramétrage - ${currentLevel.toUpperCase()} <i id='back-to-levels' class='fas fa-arrow-left'></i>`,
      "<ul>" + mapArray + "</ul>",
      "<button id='start'>Commencer<i class='far fa-play-circle'></i></button>",
    );
    utils.handleEventMinutes();
    utils.handleEventArrow();
    utils.deleteItem();

    document.getElementById("back-to-levels").addEventListener("click", () => {
      this.levelSelect();
    });

    document.getElementById("start").addEventListener("click", () => {
      this.routine();
    });
  },

  routine: function () {
    const exercice = new Exercice();

    utils.pageContent("Routine", exercice.updateCountdown(), null);
  },

  finish: function () {
    const levelOrder = ["easy", "medium", "hard"];
    const currentIndex = levelOrder.indexOf(currentLevel);
    const hasNextLevel = currentIndex < levelOrder.length - 1;

    // Marquer le niveau comme complété
    levels[currentLevel].completed = true;

    // Déverrouiller le niveau suivant
    if (hasNextLevel) {
      utils.unlockNextLevel();
    }

    utils.store();

    let finishContent = `
      <div style="text-align: center;">
        <p style="font-size: 3rem; margin: 20px 0;">🎉</p>
        <h2>Félicitations !</h2>
        <p>${currentLevel.toUpperCase()} complété avec succès</p>
      </div>
    `;

    let finishBtn = `
      <button id='restart-level' style="margin-right: 10px;">
        🔁 Refaire
      </button>
    `;

    if (hasNextLevel) {
      finishBtn += `
        <button id='next-level' style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 10px 20px; border-radius: 5px;">
          ➡️ Suivant
        </button>
      `;
    } else {
      finishBtn += `
        <button id='back-to-select' style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 10px 20px; border-radius: 5px;">
          🏠 Retour
        </button>
      `;
    }

    utils.pageContent("C'est terminé !", finishContent, finishBtn);

    document.getElementById("restart-level").addEventListener("click", () => {
      exerciceArray = [...levels[currentLevel].exercices];
      this.routine();
    });

    if (hasNextLevel) {
      document.getElementById("next-level").addEventListener("click", () => {
        this.levelSelect();
      });
    } else {
      document
        .getElementById("back-to-select")
        .addEventListener("click", () => {
          this.levelSelect();
        });
    }
  },
};

page.levelSelect();
