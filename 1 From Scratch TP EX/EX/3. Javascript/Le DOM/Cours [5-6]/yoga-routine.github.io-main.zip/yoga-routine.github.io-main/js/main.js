/**
 * Main Application
 * Orchestrates the entire yoga routine application
 */

import { levels } from "./data/levels.js";
import { DailyChallenge } from "./data/dailyChallenge.js";
import { LevelManager } from "./core/LevelManager.js";
import { Timer } from "./core/Timer.js";
import { LevelScreen } from "./ui/LevelScreen.js";
import { RoutineScreen } from "./ui/RoutineScreen.js";
import { FinishScreen } from "./ui/FinishScreen.js";

class YogaApp {
  constructor() {
    // DOM elements
    this.mainElement = document.querySelector("main");
    this.headerElement = document.querySelector("h1");

    // Initialize managers
    this.levelManager = new LevelManager(levels);
    this.dailyChallenge = new DailyChallenge();

    // Initialize screens
    this.levelScreen = new LevelScreen(
      this.mainElement,
      this.levelManager,
      this.onLevelSelect.bind(this),
      this.onDailyChallengeSelect.bind(this),
    );

    this.routineScreen = new RoutineScreen(
      this.mainElement,
      this.goToLevelSelection.bind(this),
    );

    this.finishScreen = new FinishScreen(
      this.mainElement,
      this.levelManager,
      this.restartLevel.bind(this),
      this.goToNextLevel.bind(this),
      this.goToLevelSelection.bind(this),
    );

    // Timer instance
    this.timer = null;
    this.isDailyChallenge = false;
  }

  /**
   * Initialize the app
   */
  init() {
    this.goToLevelSelection();
  }

  /**
   * Show level selection screen
   */
  goToLevelSelection() {
    this.headerElement.textContent = "Select Your Level";
    this.levelScreen.render(this.dailyChallenge);
  }

  /**
   * Handle level selection
   */
  onLevelSelect(levelKey) {
    this.isDailyChallenge = false;
    this.levelManager.setCurrentLevel(levelKey);
    this.startRoutine();
  }

  /**
   * Handle daily challenge selection
   */
  onDailyChallengeSelect() {
    this.isDailyChallenge = true;
    const challengeLevel = this.dailyChallenge.getTodayChallenge();
    this.levelManager.setCurrentLevel(challengeLevel);
    this.startRoutine();
  }

  /**
   * Start routine for current level
   */
  startRoutine() {
    const levelData = this.levelManager.getCurrentLevelData();
    const levelName = this.levelManager.getCurrentLevel().toUpperCase();

    this.headerElement.textContent = `${levelName} - Routine`;

    const exercices = levelData.exercices;

    // Create timer instance
    this.timer = new Timer(
      exercices,
      this.updateRoutineDisplay.bind(this),
      this.onRoutineComplete.bind(this),
    );

    // Show first exercise
    this.updateRoutineDisplay(this.timer.getStatus());

    // Start countdown
    this.timer.start();
  }

  /**
   * Update routine display
   */
  updateRoutineDisplay(status) {
    this.routineScreen.render(status);
  }

  /**
   * Handle routine completion
   */
  onRoutineComplete() {
    // Mark level as completed and unlock next
    this.levelManager.completeLevel();

    // If daily challenge, mark it as completed
    if (this.isDailyChallenge) {
      this.dailyChallenge.completeChallenge();
    }

    this.headerElement.textContent = "Level Completed!";
    this.finishScreen.render();
  }

  /**
   * Restart current level
   */
  restartLevel() {
    this.startRoutine();
  }

  /**
   * Go to next level
   */
  goToNextLevel() {
    this.goToLevelSelection();
  }
}

// Initialize app when DOM is ready
document.addEventListener("DOMContentLoaded", () => {
  const app = new YogaApp();
  app.init();
});
