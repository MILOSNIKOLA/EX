/**
 * Timer / Exercise Manager
 * Handles exercise timer countdown and progression
 */

export class Timer {
  constructor(exercices, onExerciseChange, onComplete) {
    this.exercices = JSON.parse(JSON.stringify(exercices)); // Deep copy
    this.currentIndex = 0;
    this.minutes = this.exercices[0].min;
    this.seconds = 0;
    this.isRunning = true;
    this.timeoutId = null;
    this.onExerciseChange = onExerciseChange;
    this.onComplete = onComplete;
  }

  /**
   * Format seconds with leading zero
   */
  formatSeconds() {
    return this.seconds < 10 ? `0${this.seconds}` : `${this.seconds}`;
  }

  /**
   * Get current exercise data
   */
  getCurrentExercise() {
    return this.exercices[this.currentIndex];
  }

  /**
   * Get progress info
   */
  getProgress() {
    return {
      current: this.currentIndex + 1,
      total: this.exercices.length,
    };
  }

  /**
   * Play sound when exercise changes
   */
  playSound() {
    try {
      const audio = new Audio("ring.mp3");
      audio.play().catch((err) => console.log("Sound error:", err));
    } catch (error) {
      console.error("Error playing sound:", error);
    }
  }

  /**
   * Start the countdown
   */
  start() {
    this.isRunning = true;
    this.tick();
  }

  /**
   * Tick function called every second
   */
  tick() {
    if (!this.isRunning) return;

    this.timeoutId = setTimeout(() => {
      if (this.minutes === 0 && this.seconds === 0) {
        // Exercise complete
        this.playSound();
        this.currentIndex++;

        if (this.currentIndex < this.exercices.length) {
          // Move to next exercise
          this.minutes = this.exercices[this.currentIndex].min;
          this.seconds = 0;
          this.onExerciseChange(this.getStatus());
          this.tick();
        } else {
          // All exercises complete
          this.isRunning = false;
          this.onComplete();
        }
      } else if (this.seconds === 0) {
        // Minute complete
        this.minutes--;
        this.seconds = 59;
        this.onExerciseChange(this.getStatus());
        this.tick();
      } else {
        // Continue countdown
        this.seconds--;
        this.onExerciseChange(this.getStatus());
        this.tick();
      }
    }, 1000);
  }

  /**
   * Get current timer status
   */
  getStatus() {
    return {
      minutes: this.minutes,
      seconds: this.formatSeconds(),
      exercice: this.getCurrentExercise(),
      progress: this.getProgress(),
    };
  }

  /**
   * Stop the timer
   */
  stop() {
    this.isRunning = false;
    if (this.timeoutId) {
      clearTimeout(this.timeoutId);
    }
  }

  /**
   * Pause the timer
   */
  pause() {
    this.isRunning = false;
  }

  /**
   * Resume the timer
   */
  resume() {
    this.isRunning = true;
    this.tick();
  }
}
