/**
 * Routine Screen
 * Displays the active exercise timer
 */

export class RoutineScreen {
  constructor(mainElement, onBack) {
    this.main = mainElement;
    this.onBack = onBack;
  }

  /**
   * Render the routine screen with current exercise
   */
  render(timerStatus) {
    const { minutes, seconds, exercice, progress } = timerStatus;

    this.main.innerHTML = `
      <div class="routine-container">
        <button class="btn-back" id="back-btn">← Back</button>
        
        <div class="timer-display">
          <span class="time">${minutes}:${seconds}</span>
        </div>

        <div class="exercise-display">
          <img 
            src="./img/${exercice.pic}.png" 
            alt="Exercise ${exercice.pic}"
            class="exercise-image"
          />
          <div class="progress-indicator">
            <span class="progress-text">${progress.current} / ${progress.total}</span>
          </div>
        </div>
      </div>
    `;

    this.attachEventListeners();
  }

  /**
   * Attach event listeners
   */
  attachEventListeners() {
    const backBtn = this.main.querySelector("#back-btn");
    if (backBtn) {
      backBtn.addEventListener("click", () => this.onBack());
    }
  }
}
